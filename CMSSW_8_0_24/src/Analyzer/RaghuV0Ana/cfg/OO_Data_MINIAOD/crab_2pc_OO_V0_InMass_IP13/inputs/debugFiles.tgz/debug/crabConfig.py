from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = '2pc_OO_V0_InMass_IP13'
config.General.workArea = 'OO_Data_MINIAOD'
config.General.transferOutputs = True
config.General.transferLogs = True
config.section_('JobType')
config.JobType.psetName = 'PbPb_2018_cfg.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.outLFNDirBase = '/store/user/bibehera/'
config.Data.totalUnits = -1
config.Data.lumiMask = 'generated_json.json'
config.Data.unitsPerJob = 3
config.Data.inputDataset = '/IonPhysics13/bibehera-2pc_OO_V0_IP13-ca42279dfc2dce710b3991c24f27a617/USER'
config.Data.splitting = 'LumiBased'
config.Data.publication = False
config.Data.secondaryInputDataset = '/IonPhysics13/OORun2025-PromptReco-v1/MINIAOD'
config.Data.outputDatasetTag = '2pc_OO_V0_InMass_IP13'
config.Data.inputDBS = 'phys03'
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
