from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = '2pc_OO_V0_IM_effcorr_cent0to50_IP27'
config.General.workArea = 'OO_Data_MINIAOD'
config.General.transferLogs = True
config.General.transferOutputs = True
config.section_('JobType')
config.JobType.psetName = 'PbPb_2018_cfg.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.secondaryInputDataset = '/IonPhysics27/OORun2025-PromptReco-v1/MINIAOD'
config.Data.publication = False
config.Data.totalUnits = -1
config.Data.splitting = 'LumiBased'
config.Data.inputDataset = '/IonPhysics27/bibehera-2pc_OO_V0_IP27-ca42279dfc2dce710b3991c24f27a617/USER'
config.Data.lumiMask = 'generated_json.json'
config.Data.inputDBS = 'phys03'
config.Data.unitsPerJob = 3
config.Data.outLFNDirBase = '/store/user/bibehera/'
config.Data.outputDatasetTag = '2pc_OO_V0_IM_effcorr_cent0to50_IP27'
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
