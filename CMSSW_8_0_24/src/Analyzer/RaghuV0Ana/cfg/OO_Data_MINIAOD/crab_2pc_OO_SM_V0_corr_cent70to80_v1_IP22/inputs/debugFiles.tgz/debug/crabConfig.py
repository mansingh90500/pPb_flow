from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.requestName = '2pc_OO_SM_V0_corr_cent70to80_v1_IP22'
config.General.transferOutputs = True
config.General.workArea = 'OO_Data_MINIAOD'
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'PbPb_2018_cfg.py'
config.section_('Data')
config.Data.inputDBS = 'phys03'
config.Data.inputDataset = '/IonPhysics22/bibehera-2pc_OO_V0_IP22-ca42279dfc2dce710b3991c24f27a617/USER'
config.Data.lumiMask = 'generated_json.json'
config.Data.splitting = 'LumiBased'
config.Data.unitsPerJob = 3
config.Data.publication = False
config.Data.totalUnits = -1
config.Data.secondaryInputDataset = '/IonPhysics22/OORun2025-PromptReco-v1/MINIAOD'
config.Data.outputDatasetTag = '2pc_OO_SM_V0_corr_cent70to80_v1_IP22'
config.Data.outLFNDirBase = '/store/user/bibehera/'
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
