import FWCore.ParameterSet.Config as cms

def RaghuV0Ana(*args, **kwargs):
  mod = cms.EDAnalyzer('RaghuV0Ana',
    mightGet = cms.optional.untracked.vstring
  )
  for a in args:
    mod.update_(a)
  mod.update_(kwargs)
  return mod
