__path__.append('/cvmfs/cms.cern.ch/el8_amd64_gcc12/cms/cmssw-patch/CMSSW_15_0_6_patch1/python/Analyzer')
