import FWCore.ParameterSet.Config as cms

def PileUpVertexFilter(*args, **kwargs):
  mod = cms.EDFilter('PileUpVertexFilter',
    mightGet = cms.optional.untracked.vstring
  )
  for a in args:
    mod.update_(a)
  mod.update_(kwargs)
  return mod
