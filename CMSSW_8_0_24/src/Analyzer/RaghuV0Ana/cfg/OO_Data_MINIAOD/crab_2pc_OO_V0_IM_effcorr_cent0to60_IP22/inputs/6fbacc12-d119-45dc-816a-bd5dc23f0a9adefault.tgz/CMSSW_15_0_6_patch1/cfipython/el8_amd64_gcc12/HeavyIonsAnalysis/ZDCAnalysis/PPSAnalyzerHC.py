import FWCore.ParameterSet.Config as cms

def PPSAnalyzerHC(*args, **kwargs):
  mod = cms.EDAnalyzer('PPSAnalyzerHC',
    mightGet = cms.optional.untracked.vstring
  )
  for a in args:
    mod.update_(a)
  mod.update_(kwargs)
  return mod
