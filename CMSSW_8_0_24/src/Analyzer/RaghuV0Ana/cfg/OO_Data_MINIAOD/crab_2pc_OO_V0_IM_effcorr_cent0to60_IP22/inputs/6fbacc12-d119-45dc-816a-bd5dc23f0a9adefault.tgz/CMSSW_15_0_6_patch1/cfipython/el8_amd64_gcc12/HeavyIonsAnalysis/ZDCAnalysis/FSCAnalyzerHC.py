import FWCore.ParameterSet.Config as cms

def FSCAnalyzerHC(*args, **kwargs):
  mod = cms.EDAnalyzer('FSCAnalyzerHC',
    mightGet = cms.optional.untracked.vstring
  )
  for a in args:
    mod.update_(a)
  mod.update_(kwargs)
  return mod
