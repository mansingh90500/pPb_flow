from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = '2pc_OO_V0_InMass_IP58'
config.General.transferOutputs = True
config.General.transferLogs = True
config.General.workArea = 'OO_Data_MINIAOD'
config.section_('JobType')
config.JobType.psetName = 'PbPb_2018_cfg.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.inputDBS = 'phys03'
config.Data.inputDataset = '/IonPhysics58/bibehera-2pc_OO_V0_IP58-ca42279dfc2dce710b3991c24f27a617/USER'
config.Data.unitsPerJob = 3
config.Data.outputDatasetTag = '2pc_OO_V0_InMass_IP58'
config.Data.lumiMask = 'generated_json.json'
config.Data.splitting = 'LumiBased'
config.Data.outLFNDirBase = '/store/user/bibehera/'
config.Data.publication = False
config.Data.totalUnits = -1
config.Data.secondaryInputDataset = '/IonPhysics58/OORun2025-PromptReco-v1/MINIAOD'
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
