from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.workArea = 'OO_Data_MINIAOD'
config.General.transferOutputs = True
config.General.requestName = '2pc_OO_V0_IM_effcorr_cent0to50_lowpT_IP27'
config.General.transferLogs = True
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'PbPb_2018_cfg.py'
config.section_('Data')
config.Data.totalUnits = -1
config.Data.secondaryInputDataset = '/IonPhysics27/OORun2025-PromptReco-v1/MINIAOD'
config.Data.inputDataset = '/IonPhysics27/bibehera-2pc_OO_V0_IP27-ca42279dfc2dce710b3991c24f27a617/USER'
config.Data.outputDatasetTag = '2pc_OO_V0_IM_effcorr_cent0to50_lowpT_IP27'
config.Data.splitting = 'LumiBased'
config.Data.lumiMask = 'generated_json.json'
config.Data.unitsPerJob = 3
config.Data.outLFNDirBase = '/store/user/bibehera/'
config.Data.publication = False
config.Data.inputDBS = 'phys03'
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
