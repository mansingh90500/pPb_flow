from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.transferOutputs = True
config.General.requestName = '2pc_OO_SM_V0_corr_cent70to80_v1_IP24'
config.General.workArea = 'OO_Data_MINIAOD'
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'PbPb_2018_cfg.py'
config.section_('Data')
config.Data.totalUnits = -1
config.Data.outLFNDirBase = '/store/user/bibehera/'
config.Data.unitsPerJob = 3
config.Data.outputDatasetTag = '2pc_OO_SM_V0_corr_cent70to80_v1_IP24'
config.Data.inputDBS = 'phys03'
config.Data.inputDataset = '/IonPhysics24/bibehera-2pc_OO_V0_IP24-ca42279dfc2dce710b3991c24f27a617/USER'
config.Data.splitting = 'LumiBased'
config.Data.lumiMask = 'generated_json.json'
config.Data.secondaryInputDataset = '/IonPhysics24/OORun2025-PromptReco-v1/MINIAOD'
config.Data.publication = False
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
