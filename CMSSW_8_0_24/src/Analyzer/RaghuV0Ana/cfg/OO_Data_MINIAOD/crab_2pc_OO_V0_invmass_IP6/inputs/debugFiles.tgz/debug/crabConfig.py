from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.workArea = 'OO_Data_MINIAOD'
config.General.transferOutputs = True
config.General.requestName = '2pc_OO_V0_invmass_IP6'
config.General.transferLogs = True
config.section_('JobType')
config.JobType.psetName = 'PbPb_2018_cfg.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.outLFNDirBase = '/store/user/bibehera/'
config.Data.outputDatasetTag = '2pc_OO_V0_IP0'
config.Data.splitting = 'LumiBased'
config.Data.secondaryInputDataset = '/IonPhysics6/OORun2025-PromptReco-v1/MINIAOD'
config.Data.inputDataset = '/IonPhysics6/bibehera-2pc_OO_V0_IP0-6b0f3ea44d7735a15be74aa96b0380e8/USER'
config.Data.unitsPerJob = 3
config.Data.totalUnits = -1
config.Data.publication = False
config.Data.lumiMask = 'generated_json.json'
config.Data.inputDBS = 'phys03'
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
