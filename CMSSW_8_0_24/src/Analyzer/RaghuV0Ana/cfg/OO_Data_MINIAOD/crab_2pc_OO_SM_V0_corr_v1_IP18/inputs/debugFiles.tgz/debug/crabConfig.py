from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = '2pc_OO_SM_V0_corr_v1_IP18'
config.General.workArea = 'OO_Data_MINIAOD'
config.General.transferOutputs = True
config.General.transferLogs = True
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'PbPb_2018_cfg.py'
config.section_('Data')
config.Data.outLFNDirBase = '/store/user/bibehera/'
config.Data.totalUnits = -1
config.Data.outputDatasetTag = '2pc_OO_SM_V0_corr_v1_IP18'
config.Data.inputDataset = '/IonPhysics18/bibehera-2pc_OO_V0_IP18-ca42279dfc2dce710b3991c24f27a617/USER'
config.Data.publication = False
config.Data.lumiMask = 'generated_json.json'
config.Data.unitsPerJob = 3
config.Data.inputDBS = 'phys03'
config.Data.secondaryInputDataset = '/IonPhysics18/OORun2025-PromptReco-v1/MINIAOD'
config.Data.splitting = 'LumiBased'
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
