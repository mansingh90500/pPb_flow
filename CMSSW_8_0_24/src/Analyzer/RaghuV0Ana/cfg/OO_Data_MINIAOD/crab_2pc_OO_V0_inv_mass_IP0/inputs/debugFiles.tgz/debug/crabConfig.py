from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.workArea = 'OO_Data_MINIAOD'
config.General.transferLogs = True
config.General.requestName = '2pc_OO_V0_inv_mass_IP0'
config.General.transferOutputs = True
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'PbPb_2018_cfg.py'
config.section_('Data')
config.Data.inputDBS = 'phys03'
config.Data.unitsPerJob = 3
config.Data.totalUnits = -1
config.Data.splitting = 'LumiBased'
config.Data.inputDataset = '/IonPhysics0/bibehera-V0_OO_IP0_Run2025_MiniAOD-ca42279dfc2dce710b3991c24f27a617/USER'
config.Data.secondaryInputDataset = '/IonPhysics0/OORun2025-PromptReco-v1/MINIAOD'
config.Data.outLFNDirBase = '/store/user/bibehera/'
config.Data.outputDatasetTag = '2pc_OO_V0_IP0'
config.Data.lumiMask = 'generated_json.json'
config.Data.publication = False
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
