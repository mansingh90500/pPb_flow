from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.transferOutputs = True
config.General.requestName = '2pc_OO_V0_SpecEff1_IP14'
config.General.workArea = 'OO_Data_MINIAOD'
config.section_('JobType')
config.JobType.psetName = 'PbPb_2018_cfg.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.splitting = 'LumiBased'
config.Data.publication = False
config.Data.lumiMask = 'generated_json.json'
config.Data.totalUnits = -1
config.Data.outputDatasetTag = '2pc_OO_V0_SpecEff1_IP14'
config.Data.inputDBS = 'phys03'
config.Data.inputDataset = '/IonPhysics14/bibehera-2pc_OO_V0_IP14-ca42279dfc2dce710b3991c24f27a617/USER'
config.Data.outLFNDirBase = '/store/user/bibehera/'
config.Data.secondaryInputDataset = '/IonPhysics14/OORun2025-PromptReco-v1/MINIAOD'
config.Data.unitsPerJob = 3
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
