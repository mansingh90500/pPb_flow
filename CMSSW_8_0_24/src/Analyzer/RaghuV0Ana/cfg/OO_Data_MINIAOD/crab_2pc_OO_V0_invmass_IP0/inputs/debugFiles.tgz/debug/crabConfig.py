from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferOutputs = True
config.General.workArea = 'OO_Data_MINIAOD'
config.General.requestName = '2pc_OO_V0_invmass_IP0'
config.General.transferLogs = True
config.section_('JobType')
config.JobType.psetName = 'PbPb_2018_cfg.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.lumiMask = 'generated_json.json'
config.Data.outLFNDirBase = '/store/user/bibehera/'
config.Data.publication = False
config.Data.totalUnits = -1
config.Data.inputDataset = '/IonPhysics0/bibehera-V0_OO_IP0_Run2025_MiniAOD-ca42279dfc2dce710b3991c24f27a617/USER'
config.Data.unitsPerJob = 3
config.Data.inputDBS = 'phys03'
config.Data.secondaryInputDataset = '/IonPhysics10/OORun2025-PromptReco-v1/MINIAOD'
config.Data.outputDatasetTag = '2pc_OO_V0_IP0'
config.Data.splitting = 'LumiBased'
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
