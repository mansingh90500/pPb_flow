from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.workArea = 'OO_Data_MINIAOD'
config.General.transferOutputs = True
config.General.requestName = '2pc_OO_V0_InM_IP0'
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'PbPb_2018_cfg.py'
config.section_('Data')
config.Data.unitsPerJob = 3
config.Data.outputDatasetTag = '2pc_OO_V0_IP0'
config.Data.outLFNDirBase = '/store/user/bibehera/'
config.Data.inputDBS = 'phys03'
config.Data.secondaryInputDataset = '/IonPhysics0/OORun2025-PromptReco-v1/MINIAOD'
config.Data.inputDataset = '/IonPhysics0/bibehera-V0_OO_IP0_Run2025_MiniAOD-ca42279dfc2dce710b3991c24f27a617/USER'
config.Data.splitting = 'LumiBased'
config.Data.lumiMask = 'generated_json.json'
config.Data.totalUnits = -1
config.Data.publication = False
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
