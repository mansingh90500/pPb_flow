from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.requestName = '2pc_OO_V0_invmass_IP54'
config.General.transferOutputs = True
config.General.transferLogs = True
config.General.workArea = 'OO_Data_MINIAOD'
config.section_('JobType')
config.JobType.psetName = 'PbPb_2018_cfg.py'
config.JobType.pluginName = 'Analysis'
config.section_('Data')
config.Data.totalUnits = -1
config.Data.splitting = 'LumiBased'
config.Data.outLFNDirBase = '/store/user/bibehera/'
config.Data.lumiMask = 'generated_json.json'
config.Data.inputDataset = '/IonPhysics54/bibehera-2pc_OO_V0_IP0-6b0f3ea44d7735a15be74aa96b0380e8/USER'
config.Data.outputDatasetTag = '2pc_OO_V0_IP0'
config.Data.inputDBS = 'phys03'
config.Data.unitsPerJob = 3
config.Data.publication = False
config.Data.secondaryInputDataset = '/IonPhysics54/OORun2025-PromptReco-v1/MINIAOD'
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
