from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferOutputs = True
config.General.requestName = '2pc_OO_V0_IM_effcorr_v1_cent0to50_IP38'
config.General.workArea = 'OO_Data_MINIAOD'
config.General.transferLogs = True
config.section_('JobType')
config.JobType.pluginName = 'Analysis'
config.JobType.psetName = 'PbPb_2018_cfg.py'
config.section_('Data')
config.Data.outputDatasetTag = '2pc_OO_V0_IM_effcorr_v1_cent0to50_IP38'
config.Data.publication = False
config.Data.splitting = 'LumiBased'
config.Data.totalUnits = -1
config.Data.unitsPerJob = 3
config.Data.inputDBS = 'phys03'
config.Data.outLFNDirBase = '/store/user/bibehera/'
config.Data.lumiMask = 'generated_json.json'
config.Data.inputDataset = '/IonPhysics38/bibehera-2pc_OO_V0_IP38-ca42279dfc2dce710b3991c24f27a617/USER'
config.Data.secondaryInputDataset = '/IonPhysics38/OORun2025-PromptReco-v1/MINIAOD'
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
