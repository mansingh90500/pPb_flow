from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.transferOutputs = True
config.General.workArea = 'pPb_Data_AOD'
config.General.requestName = '2pc_corr_ch_jpsi_in_pPb_20260402_v69_dataset2_flow_HM'
config.section_('JobType')
config.JobType.psetName = 'pPb_2016_cfg_Corr_backupWithHLT.py'
config.JobType.pluginName = 'Analysis'
config.JobType.maxMemoryMB = 3000
config.section_('Data')
config.Data.inputDataset = '/PAHighMultiplicity2/singhm-JPsi_HiSkim_pPb_2016_HM_2_dataset-4e95cfdfa2904e9c713dbc817dd5c93f/USER'
config.Data.outputDatasetTag = '2pc_corr_ch_jpsi_in_pPb_20260402_v69_dataset2_flow_HM'
config.Data.totalUnits = -1
config.Data.lumiMask = 'pPb_Collisions16_JSON.txt'
config.Data.unitsPerJob = 4
config.Data.inputDBS = 'phys03'
config.Data.splitting = 'LumiBased'
config.Data.outLFNDirBase = '/store/group/phys_heavyions/singhm/OO_Man/2pc_corr_pPb'
config.Data.secondaryInputDataset = '/PAHighMultiplicity2/PARun2016C-PromptReco-v1/AOD'
config.Data.publication = False
config.section_('Site')
config.Site.storageSite = 'T2_CH_CERN'
config.section_('User')
config.section_('Debug')
