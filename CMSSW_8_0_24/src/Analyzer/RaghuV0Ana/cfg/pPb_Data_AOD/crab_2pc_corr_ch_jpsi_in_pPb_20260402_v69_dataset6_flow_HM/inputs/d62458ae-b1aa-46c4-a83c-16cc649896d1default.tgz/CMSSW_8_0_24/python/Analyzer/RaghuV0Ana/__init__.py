#Automatically created by SCRAM
import os
__path__.append(os.path.dirname(os.path.abspath(__file__).rsplit('/Analyzer/RaghuV0Ana/',1)[0])+'/cfipython/slc7_amd64_gcc530/Analyzer/RaghuV0Ana')
