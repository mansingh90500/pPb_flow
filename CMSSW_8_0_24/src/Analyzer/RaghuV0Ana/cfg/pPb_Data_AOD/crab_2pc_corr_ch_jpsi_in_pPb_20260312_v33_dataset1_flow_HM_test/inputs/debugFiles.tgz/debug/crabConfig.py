from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.transferOutputs = True
config.General.workArea = 'pPb_Data_AOD'
config.General.requestName = '2pc_corr_ch_jpsi_in_pPb_20260312_v33_dataset1_flow_HM_test'
config.section_('JobType')
config.JobType.psetName = 'pPb_2016_cfg_Corr.py'
config.JobType.pluginName = 'Analysis'
config.JobType.maxJobRuntimeMin = 2750
config.JobType.maxMemoryMB = 3000
config.section_('Data')
config.Data.inputDataset = '/PAHighMultiplicity1/singhm-JPsi_HiSkim_pPb_2016_v2-dba4c57409660a317caeae325a670af0/USER'
config.Data.outputDatasetTag = 'pPb_Jpsi_flow_2016'
config.Data.totalUnits = -1
config.Data.unitsPerJob = 4
config.Data.splitting = 'LumiBased'
config.Data.inputDBS = 'phys03'
config.Data.publication = False
config.Data.outLFNDirBase = '/store/group/phys_heavyions/singhm/OO_Man/2pc_corr_pPb'
config.Data.lumiMask = 'pPb_Collisions16_JSON.txt'
config.Data.secondaryInputDataset = '/PAHighMultiplicity1/PARun2016C-PromptReco-v1/AOD'
config.section_('Site')
config.Site.storageSite = 'T2_CH_CERN'
