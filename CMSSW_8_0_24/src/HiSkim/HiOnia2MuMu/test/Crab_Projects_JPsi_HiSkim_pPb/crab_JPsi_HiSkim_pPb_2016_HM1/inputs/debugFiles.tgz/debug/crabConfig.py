from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.transferOutputs = True
config.General.workArea = 'Crab_Projects_JPsi_HiSkim_pPb'
config.General.requestName = 'JPsi_HiSkim_pPb_2016_HM1'
config.section_('JobType')
config.JobType.psetName = 'onia2MuMuPATHI_pPbPrompt_DATA_cfg.py'
config.JobType.pluginName = 'Analysis'
config.JobType.allowUndistributedCMSSW = True
config.JobType.maxMemoryMB = 3000
config.section_('Data')
config.Data.inputDataset = '/PAHighMultiplicity1/PARun2016C-PromptReco-v1/AOD'
config.Data.allowNonValidInputDataset = True
config.Data.publication = True
config.Data.unitsPerJob = 1
config.Data.splitting = 'FileBased'
config.Data.inputDBS = 'global'
config.Data.lumiMask = 'pPb_Collisions16_JSON.txt'
config.Data.outLFNDirBase = '/store/user/singhm/OO_Man/Skim_HM_Jpsi'
config.section_('Site')
config.Site.storageSite = 'T3_CH_CERNBOX'
config.section_('User')
config.section_('Debug')
