from WMCore.Configuration import Configuration
config = Configuration()
config.section_('General')
config.General.transferLogs = True
config.General.transferOutputs = True
config.General.workArea = 'Monte_Crab_check_HiSkim'
config.General.requestName = 'Upsilon_Coherent1s_HiSkim_check'
config.section_('JobType')
config.JobType.psetName = 'onia2MuMuPAT_pPb_80x_MC_cfg.py'
config.JobType.pluginName = 'Analysis'
config.JobType.allowUndistributedCMSSW = True
config.section_('Data')
config.Data.inputDataset = '/pLHECoherent1sStarLightMonteCarloProduction/singhm-RECOUpsilonCoherent1scheck-7ec867a76e3c5f2a337cacb1196f52aa/USER'
config.Data.allowNonValidInputDataset = True
config.Data.publication = True
config.Data.unitsPerJob = 1
config.Data.inputDBS = 'phys03'
config.Data.splitting = 'FileBased'
config.Data.outputDatasetTag = 'MCUpsilonCoherent1sHiSkim'
config.section_('Site')
config.Site.storageSite = 'T2_US_Vanderbilt'
config.section_('User')
config.section_('Debug')
